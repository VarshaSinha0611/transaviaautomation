package com.automation.pagelibrary.transavia;
import static org.testng.Assert.assertTrue;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.automation.testutilities.TestBase;
public class TransaviaHome {
	WebDriver driver; 
	private static final Logger logger = LoggerFactory.getLogger(TransaviaHome.class);
	public TransaviaHome(WebDriver ldriver)
	{
	this.driver=ldriver;
	} 
	By from = By.id("routeSelection_DepartureStation-input");
	By to = By.id("routeSelection_ArrivalStation-input");
	By departuredate = By.id("dateSelection_OutboundDate-datepicker");
	By returndate = By.id("dateSelection_IsReturnFlight-datepicker");
	By passengernumber = By.id("booking-passengers-input");
	By search = By.xpath("//label[contains(text(),'Show prices in Flying Blue Miles')]/following::button[@type='submit'][1]");
	By availableflight = By.xpath("//button[@name='selectFlight.MarketFareKey']");
	By flightstatus = By.xpath("//a[@class='h5 primary-navigation_link']/following::a[contains(text(),'Flight status')][1]");
	By origin = By.id("booking-origin-input");	
	By destination = By.id("booking-destination-input");
	By flightnumber = By.id("routeSelection_FlightNumber");
	By tommorrow = By.xpath("//span[contains(text(),'Tomorrow')]");
	By showflights = By.xpath("//button[@class='button button-primary']");
	
	
	
	
	//button[@class='button button-primary']
	
	/**
	 * Searches for flight.
	 */
	public void flighSearch(String source, String dest, String deptdate,String retdate, String numberpass){
		try{
			waitForElementToDisplay(from);
			WebElement fromlocation = driver.findElement(from);
			fromlocation.sendKeys(source);
			waitForElementToDisplay(to);
			WebElement tolocation = driver.findElement(to);
			tolocation.sendKeys(dest);
			
			waitForElementToDisplay(departuredate);
			WebElement departuredatevalue = driver.findElement(departuredate);
			departuredatevalue.clear();
			departuredatevalue.sendKeys(deptdate);
			
			waitForElementToDisplay(returndate);
			WebElement returndates = driver.findElement(returndate);
			returndates.clear();
			returndates.sendKeys(retdate);
			
			waitForElementToDisplay(passengernumber);
			WebElement passengernumbers = driver.findElement(passengernumber);
			//passengernumbers.clear();
			passengernumbers.sendKeys(numberpass);
			Thread.sleep(3000);
			waitForElementToDisplay(search);
			WebElement searches = driver.findElement(search);
			searches.click();
			System.out.println("flights information...");
				Thread.sleep(3000);
				waitForElementToDisplay(availableflight);
				List<WebElement> links=driver.findElements(availableflight);
				Iterator<WebElement> i1=links.iterator();
				while(i1.hasNext()){
					   // Iterate one by one
					    WebElement ele1=i1.next();
					    // get the text
					    String name=ele1.getText();
					   // print the text
					    System.out.println(name);
				}	
		}
		catch(InterruptedException ie){
			logger.warn("flights cant be displayed");
		}
	}
	/**
	 * finds status of flight.
	 */
	public boolean flighStatus(String source, String dest,String flightnumb){
		String flightxpath ="//p[contains(text(),'"+flightnumb+"')]";
		try{
			waitForElementToDisplay(flightstatus);
			WebElement flightsta = driver.findElement(flightstatus);
			flightsta.click();
			waitForElementToDisplay(origin);
			WebElement origins = driver.findElement(origin);
			origins.clear();
			origins.sendKeys(source);
			
			waitForElementToDisplay(destination);
			WebElement destinations = driver.findElement(destination);
			destinations.clear();
			destinations.sendKeys(dest);
			
			waitForElementToDisplay(flightnumber);
			WebElement flightnumbers = driver.findElement(flightnumber);
			flightnumbers.clear();
			flightnumbers.sendKeys(flightnumb);
			
			waitForElementToDisplay(showflights);
			WebElement showflight = driver.findElement(showflights);
			showflight.click();
			
			waitForElementToDisplay(tommorrow);
			WebElement tommorrows = driver.findElement(tommorrow);
			tommorrows.click();
			
			Thread.sleep(4000);
			
		}
		catch(InterruptedException ie){
			logger.warn("flights status cant be displayed");
		}
		if(driver.findElements(By.xpath(flightxpath)).size()>0){
			return true;
		}
		else{
			return false;
		}
	}
	
	/**
     * Waits for element to display.
     * @param locator
     */
    public void waitForElementToDisplay(By locator){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }
    
	/**
	 * Clicks on specific element based on locator.
	 * @param locatorname
	 * @param linkname
	 */
	public void clickElement(By locatorname, String linkname){
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locatorname));	
		new Actions(driver).moveToElement(driver.findElement(locatorname)).click().perform();
		WebElement link = driver.findElement(By.linkText(linkname));
		link.click();
	}
	
	/** 
	 * Navigates back to original page.
	 */
	public void navigateBack(){
		driver.navigate().back();
	}
	
	
}
