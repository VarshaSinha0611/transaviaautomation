package com.automation.testcases.transavia;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.automation.pagelibrary.transavia.TransaviaHome;
import com.automation.testutilities.ConfigRead;
import com.automation.testutilities.TestBase;

public class TransaviaFlightSearch extends TestBase {
	private static final Logger logger = LoggerFactory.getLogger(TransaviaFlightSearch.class);
	private TestBase tb;
	private WebDriver driver;
	
	TransaviaHome homepage;
	@BeforeClass
	public void setUp()
	{
		tb= new TestBase();
		driver = tb.setupApplication(); 
		logger.info("Browser launched successfully");
		homepage = new TransaviaHome(driver);	
	}
	@Test(enabled=true)
	public void testSearch() 
	{
		homepage.flighSearch("Amsterdam (Schiphol), Netherlands","Ibiza, Spain","12 Sep 2017","19 Sep 2017","2 Adults");
		logger.info("flights displayed successfully");
	}	
	@AfterClass
	public void tearDown()
	{
		tb.closeApplication();
		logger.info("Browser closed successfully");
	}
	
}
